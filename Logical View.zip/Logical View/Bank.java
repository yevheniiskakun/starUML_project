
import java.util.*;

/**
 * 
 */
public class Bank {

    /**
     * Default constructor
     */
    public Bank() {
    }

    /**
     * 
     */
    public void code;

    /**
     * 
     */
    public void adress;



    /**
     * 
     */
    public void manages() {
        // TODO implement here
    }

    /**
     * 
     */
    public void maintains() {
        // TODO implement here
    }

}