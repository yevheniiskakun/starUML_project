
import java.util.*;

/**
 * 
 */
public class Current Account {

    /**
     * Default constructor
     */
    public Current Account() {
    }

    /**
     * 
     */
    public void account no.;

    /**
     * 
     */
    public void balance;



    /**
     * 
     */
    public void withdraw() {
        // TODO implement here
    }

}