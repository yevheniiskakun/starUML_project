
import java.util.*;

/**
 * 
 */
public class Account {

    /**
     * Default constructor
     */
    public Account() {
    }

    /**
     * 
     */
    public void number;

    /**
     * 
     */
    public void balance;




    /**
     * 
     */
    public void deposit() {
        // TODO implement here
    }

    /**
     * 
     */
    public void withdraw() {
        // TODO implement here
    }

    /**
     * 
     */
    private void createTransaction() {
        // TODO implement here
    }

}