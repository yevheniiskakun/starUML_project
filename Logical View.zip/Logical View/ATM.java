
import java.util.*;

/**
 * 
 */
public class ATM {

    /**
     * Default constructor
     */
    public ATM() {
    }

    /**
     * 
     */
    public void location;

    /**
     * 
     */
    public void managedby;


    /**
     * 
     */
    public void identifies() {
        // TODO implement here
    }

    /**
     * 
     */
    public void transactions() {
        // TODO implement here
    }

}