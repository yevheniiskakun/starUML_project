
import java.util.*;

/**
 * 
 */
public class Customer extends ATM {

    /**
     * Default constructor
     */
    public Customer() {
    }

    /**
     * 
     */
    public void name;

    /**
     * 
     */
    public void address;

    /**
     * 
     */
    public void dob;

    /**
     * 
     */
    public void card number;

    /**
     * 
     */
    public void pin;



    /**
     * 
     */
    public void verifyPassword() {
        // TODO implement here
    }

}