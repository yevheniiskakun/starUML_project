
import java.util.*;

/**
 * 
 */
public class ATM Transactions {

    /**
     * Default constructor
     */
    public ATM Transactions() {
    }

    /**
     * 
     */
    public void transaction id;

    /**
     * 
     */
    public void date;

    /**
     * 
     */
    public void type;

    /**
     * 
     */
    public void amunt;

    /**
     * 
     */
    public void post balance;


    /**
     * 
     */
    public void modifies() {
        // TODO implement here
    }

}