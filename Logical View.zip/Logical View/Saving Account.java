
import java.util.*;

/**
 * 
 */
public class Saving Account extends Account {

    /**
     * Default constructor
     */
    public Saving Account() {
    }

    /**
     * 
     */
    public void account no.;

    /**
     * 
     */
    public void balance;



}